#!/bin/bash

echo "Files in current directory:"
for file in *; do
  echo "$file"
done