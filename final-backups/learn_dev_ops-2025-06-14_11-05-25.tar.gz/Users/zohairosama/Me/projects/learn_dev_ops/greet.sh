#!/bin/bash

for name in "$@"; do
    echo "👋 Hello, $name!"
done